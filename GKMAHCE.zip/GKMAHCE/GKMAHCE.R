
        #################################################
          #  A generalized kernel machine approach to identify
          # higher-order composite effects in multi-view data sets  
          #  By Md Ashad Alam, PhD                   
           ##################################################

################################################################################
#                        Library Section                                       #
################################################################################
library(base)
library(MASS)
library(lattice)
library(Matrix)
library(nlme)
library(kernlab)
library(SPA3G)
library(dummies)
library(gdata)
library(rsvd)
################################################################################
 ### Identical by state (IBS) kernel

  IBS <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
      K <- 1 - as.matrix(dist(Z, method = "manhattan") * 0.5/max(1, ncol(Z)))
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }


 LK <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
    K <- Z%*%t(Z)
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }

 
 MedianDist <- function(X)
  {
   n <- dim(X)[1]
   ab <- X%*%t(X) 
   aa <- as.matrix(diag(ab))
   Dx <-matrix(rep(aa,each=n), ncol=n, byrow=TRUE) +  matrix(rep(aa,each=n),nrow=n) - 2*ab  
   Dx <- Dx-diag(diag(Dx))
   dx <- matrix(Dx, n*n,1)
   s <- sqrt(median(dx[dx!=0]))
  return (s)
 }

  M_GK <- function(X)
  {
    SGX <-  MedianDist(X)
    sx2  <- 2*SGX*SGX
    n <- dim(X)[1]
    ab <- X%*%t(X) 
    aa <- as.matrix(diag(ab))
    D <- matrix(rep(aa,each=n), ncol=n, byrow=TRUE) 
    xx <-pmax(D + t(D) - 2*ab,  mat.or.vec(n, n))
    K <- exp(-xx/sx2)  
    Id <- diag(1, nrow =n)
    Id1 <- matrix(1, nrow = n, ncol = n)
    H <- Id - Id1/n
    CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
    CK <- (CK+t(CK))/2
    return(CK)
  }


 
 ST <- function (M1, M2) 
  {
    nn <- nrow(M1)
    S <- c()
    for (itt in 1:nn) {
        S[itt] <- sum(M1[itt, ] * M2[, itt])
    }
    trace <- sum(S)
    return(trace)
  }
 
 MT <- function (M) 
     {
     return(sum(diag(M)))
      }

   
 MP <-function (MM) 
   {
    n <- nrow(MM)
    PMM <- MM - (matrix(1, n, 1) %*% apply(MM, 2, sum))/n
    return(PMM)
    }


 mgiv<-function (X, tol = sqrt(.Machine$double.eps)) 
  {
    if (length(dim(X)) > 2L || !(is.numeric(X) || is.complex(X))) 
        stop("'X' must be a numeric or complex matrix")
    if (!is.matrix(X)) 
        X <- as.matrix(X)
    Xsvd <- svd(X)
    if (is.complex(X)) 
        Xsvd$u <- Conj(Xsvd$u)
    Positive <- Xsvd$d > max(tol * Xsvd$d[1L], 0)
    if (all(Positive)) 
        Xsvd$v %*% (1/Xsvd$d * t(Xsvd$u))
    else if (!any(Positive)) 
        array(0, dim(X)[2L:1L])
    else Xsvd$v[, Positive, drop = FALSE] %*% ((1/Xsvd$d[Positive]) * 
        t(Xsvd$u[, Positive, drop = FALSE]))
 }



 GKHOOVT <- function (BY, X,  K31)
  {
    n <- length(BY)
    aa <- glm(BY ~ X-1, family = binomial)   
    wr <-resid(aa,type="working")
    Y <- predict(aa)+wr
    be <- glm(Y~X, family = gaussian)
    er <- be$residuals
    sig2 <- var(er)
    LSum<-matrix(0,n, n)
    for(i in 1:31)
    {
    LSum<- LSum + K31[[i]]
    }

    M <- LSum
    U <- t(er) %*% M %*% (er)/(2 * sig2)
    e <- MT(MP(M))/2
   {
   Ac111 <- c()
   Ac112 <- c()
   Ic111 <- c()
     for (i in 1:31)        # 7 =mc1+mc2+mc3 +mc4+mc5 =31, if m=5
       {
      for (j in i:31)
        if (i==j)
         {
           Ic111 <- c(Ic111, MT(MP(K31[[i]])))
           Ac111 <- c(Ac111, ST(MP(K31[[i]]), MP(K31[[j]])))
         }
      else
        Ac112 <- c(Ac112, ST(MP(K31[[i]]), MP(K31[[j]])))
     }
  }    #n (n+1)/2

    ode <- Ac112 
    die <-  Ac111
    Its <- Ic111
    COV <- matrix (0,31,31)
    COV[lower.tri( COV)] <- ode
    COV <- t(COV)
    COV[lower.tri( COV)] <- ode
    diag( COV) <-  die
    correct_COV <- (COV - Its %*% t(Its)/(n - 1))/2
    Itt <- sum(correct_COV)
    k <- Itt/(2 * e)
    v <- 2 * e^2/Itt
    pvalue <- pchisq(U/k, df = v, lower.tail = FALSE)
    object <- list(Score = U, p.value = pvalue, df = v, scale = k)
    class(object) <- "Score Test: tau1=tau2=tau3=0"
    return(object)
  }

  GKHOE <- function (Y, X, K31,  par)       # m1 SNP # Y is working vector(not binary)
  {
   n <- length(Y)
    p <- length(par)
    theta.new <- par
    theta.old <- rep(0, p)
    Vs <- array(0, c(n, n, 32))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:31)
    {
    Vs[, , (i+1)] <- K31[[i]]
     }

     Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
   #W <- solve(Sigma)
    W <- mgiv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +TT(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
                H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s))                                +rho*s%*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
      cat("iteration = ",kk, "\n")
      }
    
    AVs <- matrix(0, n,n)
    for (i in 1:32)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
     
    {
    Bc111 <- matrix(0,32,32)
       for (i in 1:32)
       {
        for (j in 1:32)
        {
         Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
  eigen.sigma <- eigen(Sigma.new)
    lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
     H <- Bc111/2
     beta <- solve(t(X) %*% W.new %*% X) %*% t(X) %*% W.new %*%Y
     object <- list(VCs = theta.new, fisher.info = H, Beta = beta,
     restricted.logLik = lR)
     return(object)
  }



 GKHOIT <- function (Y, X, K31,  par)
  {
    n <- dim(X)[1]
    p <- length(par)
   theta.new <- par
   theta.old <- rep(0, p)
   Vs <- array(0, c(n, n, 32))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:31)
    {
    Vs[, , (i+1)] <- K31[[i]]
     }
     
    Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
    #W <- solve(Sigma)
    W <- mgiv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +ST(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
             #H_inv <-  solve(AI)
            H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s)) +rho * s %*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
         #cat("iteration = ",kk, "\n")
      }
    AVs <- matrix(0, n,n)
    for (i in 1:32)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
    {
    Bc111 <- matrix(0, 32, 32)
    Bc1118 <- c()
     for (i in 1:32)
      {
       for (j in 1:32)
       {
        Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
   eigen.sigma <- eigen(Sigma.new)
        lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
        W0 <- W.new
        beta <- mgiv(t(X) %*% W0 %*% X) %*% t(X) %*% W0 %*%Y
        Q <- t(Y - X %*% beta) %*% W0 %*% K31[[31]] %*% W0 %*% (Y -X %*% beta)/2
        e <- ST(R, K31[[31]])/2
        Its <- Bc111[-32,32]
        Iss <- Bc111[-32,-32]
        Itt <- (Bc111[32,32] - Its %*% mgiv(Iss) %*% Its)/2
        k <- Itt/e/2
        v = 2 * e^2/Itt
        pvalue <- pchisq(Q/k, df = v, lower.tail = F)
        object <- list(VCs = theta.new, fisher.info = Iss/2, Beta = beta, restricted.logLik = lR, Score = Q, df = v, scale = k, p.value = pvalue)
        class(object) <- "Score Test: tau3=0"
        return(object)
  }


###########
 GKHOIET <- function (BY, X, m1, m2, m3,m4, m5, cutoff=0.05)
  {
   n <- length(BY)
   K1 <- IBS(m1)
   K2 <- LK(m2)
   K3 <- LK(m3)
   K4<-  LK(m4)
   K5<-  LK(m5)
   K12 <- K1*K2
   K13 <- K1*K3
   K14 <- K1*K4
   K15 <- K1*K5
   K23 <- K2*K3
   K24 <- K2*K4
   K25 <- K2*K5
   K34 <- K3*K4
   K35 <- K3*K5
   K45 <- K4*K5
   K123 <- K1*K2*K3
   K124 <- K1*K2*K4
   K125 <- K1*K2*K5
   K134 <- K1*K3*K4
   K135 <- K1*K3*K5
   K145 <- K1*K4*K5
   K234 <- K2*K3*K4
   K235 <- K2*K3*K5
   K245 <- K2*K4*K5
   K345 <- K3*K4*K5
   K1234 <- K1*K2*K3*K4
   K1235 <- K1*K2*K3*K5
   K1245 <- K1*K2*K4*K5
   K1345 <- K1*K3*K4*K5
   K2345 <- K2*K3*K4*K5
   K12345 <- K1*K2*K3*K4*K5
  K31 <- list(K1, K2, K3, K4, K5, K12, K13, K14, K15, K23, K24, K25, K34, K35, K45, K123, K124, K125, K134,K135,  K145, K234, K235, K245, K345,  K1234, K1235, K1245, K1345, K2345, K12345)
   r <- 0.1*n
   rK1 <- rsvd(K1,r)[[2]]
   rK2 <- rsvd(K2,r)[[2]]
   rK3 <- rsvd(K3,r)[[2]]
   rK4<-  rsvd(K4,r)[[2]]
   rK5<-  rsvd(K5,r)[[2]]
   rK12 <- rsvd(K12,r)[[2]]
   rK13 <- rsvd(K13,r)[[2]]
   rK14 <- rsvd(K14,r)[[2]]
   rK15 <- rsvd(K15,r)[[2]]
   rK23 <- rsvd(K23,r)[[2]]
   rK24 <- rsvd(K24,r)[[2]]
   rK25 <- rsvd(K25,r)[[2]]
   rK34 <- rsvd(K34,r)[[2]]
   rK35 <- rsvd(K35,r)[[2]]
   rK45 <- rsvd(K45,r)[[2]]
   rK123 <- rsvd(K123,r)[[2]]
   rK124 <- rsvd(K124,r)[[2]]
   rK125 <- rsvd(K125,r)[[2]]
   rK134 <- rsvd(K134,r)[[2]]
   rK135 <- rsvd(K135,r)[[2]]
   rK145 <- rsvd(K145,r)[[2]]
   rK234 <- rsvd(K234,r)[[2]]
   rK235 <- rsvd(K235,r)[[2]]
   rK245 <- rsvd(K245,r)[[2]]
   rK345 <- rsvd(K345,r)[[2]]
   rK1234 <- rsvd(K1234,r)[[2]]
   rK1235 <- rsvd(K1235,r)[[2]]
   rK1245 <- rsvd(K1245,r)[[2]]
   rK1345 <- rsvd(K1345,r)[[2]]
   rK2345 <- rsvd(K2345,r)[[2]]
   rK12345 <- rsvd(K12345,r)[[2]]
   rK31m1 <-rK1+rK2+rK3+ rK4+rK5+rK12+ rK13+ rK14+rK15+rK23+rK24+rK25+ rK34+ rK35+ rK45
   rK31m2 <- rK123+rK124+rK125+rK134+rK135+rK145+rK234+rK235+rK245+rK345+rK1234+ rK1235+rK1245+rK1345+rK2345+ rK12345
   rK31<-rK31m1+rK31m2
   aa <- glm(BY ~X+ rK31,family = binomial)
    mu <- predict(aa, type = "response")
    D <- diag(mu*(1-mu))
    #Y <- solve(D)%*%(BY-mu)+ X%*%(beta)   # working vector OR
    wr <-resid(aa,type="working") # working residual
    Y <-scale(as.vector(predict(aa)+wr))
   GKHOall <- GKHOOVT(BY, X,  K31)
   if(GKHOall$p.value < cutoff)
      {
       setpara <- c(0, 1e-05, 1e-04, 0.001, 0.01) # shoult wirte (0 - 1)
        testI <- vector("list", length(setpara))
        for (i in 1:length(setpara))
           {
             par <- c(var(Y), rep(setpara[i], ))
              testI[[i]] <- GKHOIT(Y, X, K31,  par)
            }
           testLR <- c()
            for (i in 1:length(testI))
             {
              testLR[i] <- testI[[i]]$restricted.logLik
              }
            HOI <- testI[[which.max(testLR)]]
            parall <- c(HOI$VCs, 0.01) # under nulmodel 0.01 =0
            allcomp <- GKHOE(Y, X, K31, parall)
            result <- list(Overall_test = GKHOall, HOInterstion = HOI, Allcomp = allcomp, RL = testLR)
        }
        else
        {
         V <- t(t(c(rep(9999999, 31))))
         allcomp <- list (V)
         names(allcomp) <- "VCs"
        object <- list(VCs = V, fisher.info =9999999, Beta = 9999999, restricted.logLik = 9999999, Score = 9999999, df = 9999999, scale = 9999999, p.value = "9999999")
       result <- list(Overall_test = GKHOall, HOInterstion = object, Allcomp = allcomp, RL = 9999999)
        }
    return(result)
 }

