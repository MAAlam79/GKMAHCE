
        #################################################
          #  A generalized kernel machine approach to identify
          # higher-order composite effects in multi-view data sets  
          #  By Md Ashad Alam, PhD                   
           ##################################################

################################################################################
#                        Library Section                                       #
################################################################################
library(base)
library(MASS)
library(lattice)
library(Matrix)
library(nlme)
library(kernlab)
library(CCA)
library(SPA3G)
library(dummies)
library(SKAT)
library(Hmisc)
library(gdata)
library(rsvd)
library(pROC)

################################################################################
 
  
   
 ecolm2 <- function(A,B) 
   {
    AB <- rep(0,nrow(A))
    for(i in 1:ncol(A))
    {
   	for (j in 1:ncol(B))
    	{
       AB <- cbind(AB, A[,i]* B[,j])
  	 }
     }
    return(AB[,-1])
   }



 
 ecolm3 <- function(A,B,C) 
  {
   ABC <- rep(0,nrow(A))
   for(i in 1:ncol(A))
    {
   	for (j in 1:ncol(B))
    	{
        for (k in 1:ncol(C))
    	    {
    	     ABC <- cbind(ABC, A[,i]* B[,j]*C[,k])
  	    }
       }
    }
  return(ABC[,-1])
 }
     

  ecolm4 <- function(A,B,C, D) 
  {
   ABCD <- rep(0,nrow(A))
   for(i in 1:ncol(A))
    {
   	for (j in 1:ncol(B))
    	{
        for (k in 1:ncol(C))
    	    {
           for (d in 1:ncol(D))
    	     {
    	      ABCD <- cbind(ABCD, A[,i]* B[,j]*C[,k]*D[,d])
           }
  	    }
       }
    }
  return(ABCD[,-1])
 }
     
 ecolm5 <- function(A,B,C, D,E) 
  {
   ABCDE <- rep(0,nrow(A))
   for(i in 1:ncol(A))
    {
   	for (j in 1:ncol(B))
    	{
        for (k in 1:ncol(C))
    	    {
           for (d in 1:ncol(D))
    	     {
            for (e in 1:ncol(E))
    	     {
    	      ABCDE <- cbind(ABCDE, A[,i]* B[,j]*C[,k]*D[,d]*E[,e])
            }
           }
  	    }
       }
    }
  return(ABCDE[,-1])
 }



 
     
 


 Linearpca <-function(X)
  {
	n <- dim(X)[1]
      r <-dim(X)[2]
	me <- matrix(apply(X, 2, mean), n, r, byrow=TRUE)
	CX <- X-me # this COV based for corelation based /sd also(scale need)
      svdev <- svd(CX)
      eigv <-  (svdev$d)^2/(n-1)
      prinvec <- svdev$v  #  right  svd
      princom <-  svdev$u%*%diag(svdev$d)  # u is left svd
      ans <- list(eigv, princom)  # list for multiple return
      names(ans)[[1]]<-"Eigvals"
      names(ans)[[2]]<-"Princoms"
      return(ans)
  }
 
   


 SKATLinerPCA <- function (Y,X, m1, m2, m3, m4, m5)
      {
      pcam1 <-Linearpca(m1)
      pv1 <- pcam1$Eigvals
      rpv1 <- cumsum(pv1/sum(pv1)) 
      r1 <- min(max(2, sum(rpv1 <= 0.80)),4)
      PM1 <- pcam1$Princoms[,1:r1] # full components
	pcam2 <-Linearpca(m2)
      pv2 <- pcam2$Eigvals
      rpv2 <- cumsum(pv2/sum(pv2)) 
      r2 <- min(max(2, sum(rpv2 <= 0.80)),4)
      PM2 <- pcam2$Princoms[,1:r2]
  	pcam3 <- Linearpca(m3)
      pv3 <- pcam3$Eigvals
      rpv3 <- cumsum(pv3/sum(pv3)) 
      r3 <- min(max(2, sum(rpv3 <= 0.80)),4)
      PM3 <- pcam3$Princoms[,1:r3]
      pcam4 <-Linearpca(m4)
       pcam4 <-Linearpca(m4)
      pv4 <- pcam4$Eigvals
      rpv4 <- cumsum(pv4/sum(pv4)) 
      r4 <- min(max(2, sum(rpv4 <= 0.80)),4)
      PM4 <- pcam4$Princoms[,1:r4] # full components
      pcam5 <-Linearpca(m1)
      pv5 <- pcam5$Eigvals
      rpv5 <- cumsum(pv5/sum(pv5)) 
      r5 <- min(max(2, sum(rpv5 <= 0.80)),4)
      PM5 <- pcam5$Princoms[,1:r5] # full components
      PM12 <-  ecolm2(PM1, PM2) 
      PM13 <-  ecolm2(PM1, PM3) 
      PM14<-  ecolm2(PM1, PM3)
      PM15 <-  ecolm2(PM1, PM3)
      PM23 <-  ecolm2(PM2, PM3) 
      PM24 <-  ecolm2(PM2, PM4) 
      PM25 <-  ecolm2(PM2, PM5) 
      PM34 <-  ecolm2(PM3, PM4)  
      PM35 <-  ecolm2(PM3, PM5) 
      PM45 <-  ecolm2(PM4, PM5)      
      PM123 <- ecolm3(PM1, PM2, PM3) 
      PM124 <- ecolm3(PM1, PM2, PM4) 
      PM125 <- ecolm3(PM1, PM2, PM5) 
      PM234 <- ecolm3(PM2, PM3, PM4)
      PM235 <- ecolm3(PM2, PM3, PM5)
      PM345 <- ecolm3(PM3, PM4, PM5)
      PM1234 <- ecolm4(PM1, PM2, PM3, PM4)
      PM1235 <- ecolm4(PM1, PM2, PM3, PM5)
      PM1245 <- ecolm4(PM1, PM2, PM4, PM5)
      PM1345 <- ecolm4(PM1, PM3, PM4, PM5)
      PM2345 <- ecolm4(PM2, PM3, PM4, PM5)
   	 PM12345 <- ecolm5(PM1,PM2, PM3, PM4, PM5)
 	  AX  <- cbind(X, PM1, PM2, PM3, PM12, PM13, PM14, PM15, PM23, PM24, PM25, PM34, PM35, PM45, PM123, PM124, PM125, PM234, PM235, PM345, PM1234, PM1235, PM1245, PM2345, PM12345)
    	objov <-SKAT_Null_Model(Y ~ X, out_type="C")
      pVal <- SKAT(AX, objov, kernel="IBS")$p.value
      objIR<-SKAT_Null_Model(Y ~X+PM12+PM13+PM23, out_type="C")
      INPV <-SKAT(PM123, objIR)$p.value
      PCApv <- cbind(pVal, INPV)
      return(PCApv)     
    }


  

### Identical by state (IBS) kernel

  IBS <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
      K <- 1 - as.matrix(dist(Z, method = "manhattan") * 0.5/max(1, ncol(Z)))
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }

 LK <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
    K <- Z%*%t(Z)
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }




 MedianDist <- function(X)
  {
   n <- dim(X)[1]
   ab <- X%*%t(X) 
   aa <- as.matrix(diag(ab))
   Dx <-matrix(rep(aa,each=n), ncol=n, byrow=TRUE) +  matrix(rep(aa,each=n),nrow=n) - 2*ab  
   Dx <- Dx-diag(diag(Dx))
   dx <- matrix(Dx, n*n,1)
   s <- sqrt(median(dx[dx!=0]))
  return (s)
 }

  


 M_GK <- function(X)
  {
    SGX <-  MedianDist(X)
    sx2  <- 2*SGX*SGX
    n <- dim(X)[1]
    ab <- X%*%t(X) 
    aa <- as.matrix(diag(ab))
    D <- matrix(rep(aa,each=n), ncol=n, byrow=TRUE) 
    xx <-pmax(D + t(D) - 2*ab,  mat.or.vec(n, n))
    K <- exp(-xx/sx2)  
    Id <- diag(1, nrow =n)
    Id1 <- matrix(1, nrow = n, ncol = n)
    H <- Id - Id1/n
    CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
    CK <- (CK+t(CK))/2
    return(CK)
  }


 
 ST <- function (M1, M2) 
  {
    nn <- nrow(M1)
    S <- c()
    for (itt in 1:nn) {
        S[itt] <- sum(M1[itt, ] * M2[, itt])
    }
    trace <- sum(S)
    return(trace)
  }
 
 MT <- function (M) 
     {
     return(sum(diag(M)))
      }

   
 MP <-function (MM) 
   {
    n <- nrow(MM)
    PMM <- MM - (matrix(1, n, 1) %*% apply(MM, 2, sum))/n
    return(PMM)
    }


 mgiv<-function (X, tol = sqrt(.Machine$double.eps)) 
  {
    if (length(dim(X)) > 2L || !(is.numeric(X) || is.complex(X))) 
        stop("'X' must be a numeric or complex matrix")
    if (!is.matrix(X)) 
        X <- as.matrix(X)
    Xsvd <- svd(X)
    if (is.complex(X)) 
        Xsvd$u <- Conj(Xsvd$u)
    Positive <- Xsvd$d > max(tol * Xsvd$d[1L], 0)
    if (all(Positive)) 
        Xsvd$v %*% (1/Xsvd$d * t(Xsvd$u))
    else if (!any(Positive)) 
        array(0, dim(X)[2L:1L])
    else Xsvd$v[, Positive, drop = FALSE] %*% ((1/Xsvd$d[Positive]) * 
        t(Xsvd$u[, Positive, drop = FALSE]))
 }



 GKHOOVT <- function (BY, X,  K31)
  {
    n <- length(BY)
    aa <- glm(BY ~ X-1, family = binomial) # since no random effect  we use glam
    #beta <- aa$coefficients
    #mu <- predict(aa, type = "response")
    #D <- diag(mu*(1-mu))
    #Y <- solve(D)%*%(BY-mu)+ X%*%(beta)   # working vector OR
     wr <-resid(aa,type="working")
    Y <- predict(aa)+wr
    be <- glm(Y~X, family = gaussian)
    er <- be$residuals
    sig2 <- var(er)
    LSum<-matrix(0,n, n)
    for(i in 1:31)
    {
    LSum<- LSum + K31[[i]]
    }

    M <- LSum
    U <- t(er) %*% M %*% (er)/(2 * sig2)
    e <- MT(MP(M))/2
   {
   Ac111 <- c()
   Ac112 <- c()
   Ic111 <- c()
     for (i in 1:31)        # 7 =mc1+mc2+mc3 +mc4+mc5 =31, if m=5
       {
      for (j in i:31)
        if (i==j)
         {
           Ic111 <- c(Ic111, MT(MP(K31[[i]])))
           Ac111 <- c(Ac111, ST(MP(K31[[i]]), MP(K31[[j]])))
         }
      else
        Ac112 <- c(Ac112, ST(MP(K31[[i]]), MP(K31[[j]])))
     }
  }    #n (n+1)/2

    ode <- Ac112 
    die <-  Ac111
    Its <- Ic111
    COV <- matrix (0,31,31)
    COV[lower.tri( COV)] <- ode
    COV <- t(COV)
    COV[lower.tri( COV)] <- ode
    diag( COV) <-  die
    correct_COV <- (COV - Its %*% t(Its)/(n - 1))/2
    Itt <- sum(correct_COV)
    k <- Itt/(2 * e)
    v <- 2 * e^2/Itt
    pvalue <- pchisq(U/k, df = v, lower.tail = FALSE)
    object <- list(Score = U, p.value = pvalue, df = v, scale = k)
    class(object) <- "Score Test: tau1=tau2=tau3=0"
    return(object)
  }





 GKHOE <- function (Y, X, K31,  par)       # m1 SNP # Y is working vector(not binary)
  {
   n <- length(Y)
    p <- length(par)
    theta.new <- par
    theta.old <- rep(0, p)
    Vs <- array(0, c(n, n, 32))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:31)
    {
    Vs[, , (i+1)] <- K31[[i]]
     }

     Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
   #W <- solve(Sigma)
    W <- mgiv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +TT(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
                H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s)) +rho * s                %*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
      cat("iteration = ",kk, "\n")
      }
    
    AVs <- matrix(0, n,n)
    for (i in 1:32)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
     
    {
    Bc111 <- matrix(0,32,32)
       for (i in 1:32)
       {
        for (j in 1:32)
        {
         Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
  eigen.sigma <- eigen(Sigma.new)
    lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
     H <- Bc111/2
     beta <- solve(t(X) %*% W.new %*% X) %*% t(X) %*% W.new %*%Y
     object <- list(VCs = theta.new, fisher.info = H, Beta = beta,
     restricted.logLik = lR)
     return(object)
  }



 GKHOIT <- function (Y, X, K31,  par)
  {
    n <- dim(X)[1]
    p <- length(par)
   theta.new <- par
   theta.old <- rep(0, p)
   Vs <- array(0, c(n, n, 32))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:31)
    {
    Vs[, , (i+1)] <- K31[[i]]
     }
     
    Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
    #W <- solve(Sigma)
    W <- mgiv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +ST(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
             #H_inv <-  solve(AI)
            H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s)) +rho * s %*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
         #cat("iteration = ",kk, "\n")
      }
    AVs <- matrix(0, n,n)
    for (i in 1:32)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
    {
    Bc111 <- matrix(0, 32, 32)
    Bc1118 <- c()
     for (i in 1:32)
      {
       for (j in 1:32)
       {
        Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
   eigen.sigma <- eigen(Sigma.new)
        lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
        W0 <- W.new
        beta <- mgiv(t(X) %*% W0 %*% X) %*% t(X) %*% W0 %*%Y
        Q <- t(Y - X %*% beta) %*% W0 %*% K31[[31]] %*% W0 %*% (Y -X %*% beta)/2
        e <- ST(R, K31[[31]])/2
        Its <- Bc111[-32,32]
        Iss <- Bc111[-32,-32]
        Itt <- (Bc111[32,32] - Its %*% mgiv(Iss) %*% Its)/2
        k <- Itt/e/2
        v = 2 * e^2/Itt
        pvalue <- pchisq(Q/k, df = v, lower.tail = F)
        object <- list(VCs = theta.new, fisher.info = Iss/2, Beta = beta, restricted.logLik = lR, Score = Q, df = v, scale = k, p.value = pvalue)
        class(object) <- "Score Test: tau3=0"
        return(object)
  }




###########
 GKHOIET <- function (BY, X, m1, m2, m3,m4, m5, cutoff=0.05)
  {
   n <- length(BY)
   K1 <- IBS(m1)
   K2 <- LK(m2)
   K3 <- LK(m3)
   K4<-  LK(m4)
   K5<-  LK(m5)
   K12 <- K1*K2
   K13 <- K1*K3
   K14 <- K1*K4
   K15 <- K1*K5
   K23 <- K2*K3
   K24 <- K2*K4
   K25 <- K2*K5
   K34 <- K3*K4
   K35 <- K3*K5
   K45 <- K4*K5
   K123 <- K1*K2*K3
   K124 <- K1*K2*K4
   K125 <- K1*K2*K5
   K134 <- K1*K3*K4
   K135 <- K1*K3*K5
   K145 <- K1*K4*K5
   K234 <- K2*K3*K4
   K235 <- K2*K3*K5
   K245 <- K2*K4*K5
   K345 <- K3*K4*K5
   K1234 <- K1*K2*K3*K4
   K1235 <- K1*K2*K3*K5
   K1245 <- K1*K2*K4*K5
   K1345 <- K1*K3*K4*K5
   K2345 <- K2*K3*K4*K5
   K12345 <- K1*K2*K3*K4*K5
  K31 <- list(K1, K2, K3, K4, K5, K12, K13, K14, K15, K23, K24, K25, K34, K35, K45, K123, K124, K125, K134,K135,  K145, K234, K235, K245, K345,  K1234, K1235, K1245, K1345, K2345, K12345)
   r <- 0.1*n
   rK1 <- rsvd(K1,r)[[2]]
   rK2 <- rsvd(K2,r)[[2]]
   rK3 <- rsvd(K3,r)[[2]]
   rK4<-  rsvd(K4,r)[[2]]
   rK5<-  rsvd(K5,r)[[2]]
   rK12 <- rsvd(K12,r)[[2]]
   rK13 <- rsvd(K13,r)[[2]]
   rK14 <- rsvd(K14,r)[[2]]
   rK15 <- rsvd(K15,r)[[2]]
   rK23 <- rsvd(K23,r)[[2]]
   rK24 <- rsvd(K24,r)[[2]]
   rK25 <- rsvd(K25,r)[[2]]
   rK34 <- rsvd(K34,r)[[2]]
   rK35 <- rsvd(K35,r)[[2]]
   rK45 <- rsvd(K45,r)[[2]]
   rK123 <- rsvd(K123,r)[[2]]
   rK124 <- rsvd(K124,r)[[2]]
   rK125 <- rsvd(K125,r)[[2]]
   rK134 <- rsvd(K134,r)[[2]]
   rK135 <- rsvd(K135,r)[[2]]
   rK145 <- rsvd(K145,r)[[2]]
   rK234 <- rsvd(K234,r)[[2]]
   rK235 <- rsvd(K235,r)[[2]]
   rK245 <- rsvd(K245,r)[[2]]
   rK345 <- rsvd(K345,r)[[2]]
   rK1234 <- rsvd(K1234,r)[[2]]
   rK1235 <- rsvd(K1235,r)[[2]]
   rK1245 <- rsvd(K1245,r)[[2]]
   rK1345 <- rsvd(K1345,r)[[2]]
   rK2345 <- rsvd(K2345,r)[[2]]
   rK12345 <- rsvd(K12345,r)[[2]]
   rK31m1 <-rK1+rK2+rK3+ rK4+rK5+rK12+ rK13+ rK14+rK15+rK23+rK24+rK25+ rK34+ rK35+ rK45
   rK31m2 <- rK123+rK124+rK125+rK134+rK135+rK145+rK234+rK235+rK245+rK345+rK1234+ rK1235+rK1245+rK1345+rK2345+ rK12345
   rK31<-rK31m1+rK31m2
   aa <- glm(BY ~X+ rK31,family = binomial)
    mu <- predict(aa, type = "response")
    D <- diag(mu*(1-mu))
    #Y <- solve(D)%*%(BY-mu)+ X%*%(beta)   # working vector OR
    wr <-resid(aa,type="working") # working residual
    Y <-scale(as.vector(predict(aa)+wr))
   GKHOall <- GKHOOVT(BY, X,  K31)
   if(GKHOall$p.value < cutoff)
      {
       setpara <- c(0, 1e-05, 1e-04, 0.001, 0.01) # shoult wirte (0 - 1)
        testI <- vector("list", length(setpara))
        for (i in 1:length(setpara))
           {
             par <- c(var(Y), rep(setpara[i], ))
              testI[[i]] <- GKHOIT(Y, X, K31,  par)
            }
           testLR <- c()
            for (i in 1:length(testI))
             {
              testLR[i] <- testI[[i]]$restricted.logLik
              }
            HOI <- testI[[which.max(testLR)]]
            parall <- c(HOI$VCs, 0.01) # under nulmodel 0.01 =0
            allcomp <- GKHOE(Y, X, K31, parall)
            result <- list(Overall_test = GKHOall, HOInterstion = HOI, Allcomp = allcomp, RL = testLR)
        }
        else
        {
         V <- t(t(c(rep(9999999, 31))))
         allcomp <- list (V)
         names(allcomp) <- "VCs"
        object <- list(VCs = V, fisher.info =9999999, Beta = 9999999, restricted.logLik = 9999999, Score = 9999999, df = 9999999, scale = 9999999, p.value = "9999999")
       result <- list(Overall_test = GKHOall, HOInterstion = object, Allcomp = allcomp, RL = 9999999)
        }
    return(result)
 }


###############################

##########################################PCA #################################################################
 
 parLinerPCA <- function (Y, X, m1, m2, m3, m4, m5)
  {
 	pcam1 <-  Linearpca(m1)
 	PM1 <- pcam1$Princoms[,1]
 	pcam2 <- Linearpca(m2)
 	PM2 <- pcam2$Princoms[,1]
  	pcam3 <-Linearpca(m3)
 	PM3 <- pcam3$Princoms[,1]
      pcam4 <-  Linearpca(m4)
 	PM4 <- pcam4$Princoms[,1]
      pcam5 <-  Linearpca(m1)
 	PM5 <- pcam5$Princoms[,1]
 	AX  <- cbind(X,m1,m2,m3, m4, m5,  PM1*PM2*PM3*PM4*PM5)
 	MR <- glm(Y ~AX)
 	SMR <-summary(MR)
 	pVal <- anova(MR)$'Pr(>F)'[1] #overall p-value
      PP <- SMR$coefficients
   	INPV <- PP[nrow(PP),4] # 3rd order Interaction  P-value
      PCApv <- cbind( pVal, INPV)
      return(PCApv)     
 }


 fulLinerPCA <- function (Y,X, m1, m2, m3, m4, m5)
  {
      pcam1 <-Linearpca(m1)
      pv1 <- pcam1$Eigvals
      rpv1 <- cumsum(pv1/sum(pv1)) 
      r1 <- min(max(2, sum(rpv1 <= 0.80)),4)
      PM1 <- pcam1$Princoms[,1:r1] # full components
	pcam2 <-Linearpca(m2)
      pv2 <- pcam2$Eigvals
      rpv2 <- cumsum(pv2/sum(pv2)) 
      r2 <- min(max(2, sum(rpv2 <= 0.80)),4)
      PM2 <- pcam2$Princoms[,1:r2]
  	pcam3 <- Linearpca(m3)
      pv3 <- pcam3$Eigvals
      rpv3 <- cumsum(pv3/sum(pv3)) 
      r3 <- min(max(2, sum(rpv3 <= 0.80)),4)
 	PM3 <- pcam3$Princoms[,1:r3]
      pcam4 <-Linearpca(m4)
      pv4 <- pcam4$Eigvals
      rpv4 <- cumsum(pv4/sum(pv4)) 
      r4 <- min(max(2, sum(rpv4 <= 0.80)),4)
      PM4 <- pcam4$Princoms[,1:r4] # full components
      pcam5 <-Linearpca(m1)
      pv5 <- pcam5$Eigvals
      rpv5 <- cumsum(pv5/sum(pv5)) 
      r5 <- min(max(2, sum(rpv5 <= 0.80)),4)
      PM5 <- pcam5$Princoms[,1:r5] # full components
      PM12 <-  ecolm2(PM1, PM2) 
      PM13 <-  ecolm2(PM1, PM3) 
      PM14<-  ecolm2(PM1, PM3)
      PM15 <-  ecolm2(PM1, PM3)
      PM23 <-  ecolm2(PM2, PM3) 
      PM24 <-  ecolm2(PM2, PM4) 
      PM25 <-  ecolm2(PM2, PM5) 
      PM34 <-  ecolm2(PM3, PM4)  
      PM35 <-  ecolm2(PM3, PM5) 
      PM45 <-  ecolm2(PM4, PM5)      
      PM123 <- ecolm3(PM1, PM2, PM3) 
      PM124 <- ecolm3(PM1, PM2, PM4) 
      PM125 <- ecolm3(PM1, PM2, PM5) 
      PM234 <- ecolm3(PM2, PM3, PM4)
      PM235 <- ecolm3(PM2, PM3, PM5)
      PM345 <- ecolm3(PM3, PM4, PM5)
      PM1234 <- ecolm4(PM1, PM2, PM3, PM4)
      PM1235 <- ecolm4(PM1, PM2, PM3, PM5)
      PM1245 <- ecolm4(PM1, PM2, PM4, PM5)
      PM1345 <- ecolm4(PM1, PM3, PM4, PM5)
      PM2345 <- ecolm4(PM2, PM3, PM4, PM5)
   	PM12345 <- ecolm5(PM1,PM2, PM3, PM4, PM5)
 	AX  <- cbind(X, PM1, PM2, PM3, PM12, PM13, PM14, PM15, PM23, PM24, PM25, PM34, PM35, PM45, PM123, PM124, PM125, PM234, PM235, PM345, PM1234, PM1235, PM1245, PM2345, PM12345)
      gg <-sample(1: dim(AX)[2],dim(AX)[1])	
      MR <- glm(Y ~ AX[,gg])
 	SMR <-summary(MR)
 	pVal <- anova(MR)$'Pr(>F)'[1] #overall p-value
      PP <-SMR$coefficients 
   	INPV <- PP[nrow(PP),4] # 3rd order Interaction  P-value
      PCApv <- cbind( pVal, INPV)
  return(PCApv)     
}

 

############################################data##############################################################
 randu <- function(p)
     {
   	y <- runif(p,0,1)*3 - 1.5
  	y <- sign(y)*(abs(y) + 0.5)
      return(y)
     }
############
mdummy<-function (x, data = NULL, sep = "", drop = TRUE, fun = as.integer, 
    verbose = FALSE) 
{
    if (is.null(data)) {
        name <- as.character(sys.call(1))[2]
        name <- sub("^(.*\\$)", "", name)
        name <- sub("\\[.*\\]$", "", name)
    }
    else {
        if (length(x) > 1) 
            stop("More than one variable provided to produce dummy variable.")
        name <- x
        x <- data[, name]
    }
    if (drop == FALSE && class(x) == "factor") {
        x <- factor(x, levels = levels(x), exclude = NULL)
    }
    else {
        x <- factor(x, exclude = NULL)
    }
    if (length(levels(x)) < 2) {
        if (verbose) 
            warning(name, " has only 1 level. Producing dummy variable anyway.")
        return(matrix(rep(1, length(x)), ncol = 1, dimnames = list(rownames(x), 
            c(paste(name, sep, x[[1]], sep = "")))))
    }
    mm <- model.matrix(~x - 1, model.frame(~x - 1), contrasts = FALSE)
    colnames.mm <- colnames(mm)
    if (verbose) 
        cat(" ", name, ":", ncol(mm), "dummy varibles created\n")
    mm <- matrix(fun(mm), nrow = nrow(mm), ncol = ncol(mm), dimnames = list(NULL, 
        colnames.mm))
    colnames(mm) <- sub("^x", paste(name, sep, sep = ""), colnames(mm))
    if (!is.null(row.names(data))) 
        rownames(mm) <- rownames(data)
    return(mm)
}
####################



######################## Data##############################

 #Generate Cubicle Points
 # Data point
 # nDim
  GCP <- function(DP,nDim,center=rep(0,nDim),l=1){ 
    z <-  matrix(runif(DP*nDim,-1,1),ncol=nDim)
    z <-  as.data.frame(
            t(apply(z*(l/2),1,'+',center))
          )
    names(z) <- make.names(seq_len(nDim))
    return(z)
  }
 
 #Generate Sphere Points

 GSP <- function(DP,nDim,center=rep(0,nDim),r=1){
    #generate the polar coordinates!
    z <-  matrix(runif(DP*nDim,-pi,pi),ncol=nDim)
    z[,nDim] <- z[,nDim]/2
    #recalculate them to cartesians
    sin.z <- sin(z)
    cos.z <- cos(z)
    cos.z[,nDim] <- 1  # see the formula for n.spheres
    w <- sapply(1:nDim, function(i){
        if(i==1){
          cos.z[,1]
        } else {
          cos.z[,i]*apply(sin.z[,1:(i-1),drop=F],1,prod)
        }
    })*sqrt(runif(DP,0,r^2))

    w <-  as.data.frame(
            t(apply(w,1,'+',center))
          )

    names(w) <- make.names(seq_len(nDim))
    return(w)
}

 df <- data.frame(
    radius = runif(1000),
    inclination = 2*pi*runif(1000),
    azimuth = 2*pi*runif(1000)
)
 



                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        

 Sim5DHOILKPCA <- function (n, alpha1, alpha2, alpha3,  alpha4,  alpha5)
  {
  	A <- expand.grid(height = seq(53, 80, 1), weight = seq(60, 225, 2))
  	X <- A[1:n,] +3*rnorm(n, 0,1) #highet +/-
  	X <- scale(as.matrix(X))
      z1 <- replicate(10, runif(n,0,1))
      z2 <- replicate(10, runif(n,0,1))
      V1 <-  (z1+2*z2)^(1/7)
      m1 <-scale(as.matrix(V1))

	b1 <- 0.5
  	b2 <- 0.5
  	beta <- c(b1, b2)   
	sig <- 0.5 #noise level
	p2 <- 10
    	b <- rep(0,p2)
	b[1:p2] <- randu(p2) #using rndu.r file
	maf  <-  runif(p2,0.2, 0.4) # (0,1)/5+0.2  # form uiform distribution
	mu <- rnorm(n, 0, 1)
      mu <- sign(mu)*(abs(mu)+0.1);# normal distribution add some samll term 0.1
	mu <-mu*sig # Common feature
      ind <- rep(F,p2)        #logical(pt) # logical zeors
      ind <- as.integer(ind)
	ind[1:p2] <- 1 # take 1 1: p2  matrix( rnorm(N*M,mean=0,sd=1), N, M) 
	m2 <- mu%*%t(b)+matrix(rnorm(n*p2, 0, 1), n,p2)*sig # SNP      
 	#  tO CONSTRACT Normal distribution o binomial distribution
	for ( i in 1: p2)
 		{
   		 p <- maf[i]
    		 bias <- log(1/p-1)
    		if (ind[i]==TRUE)
		  {
    			gt <- m2[,i]
    			gt <- 1/(1+exp(-gt+bias)) # for correlated variables
      	  }
     		else
     			gt <- 1/(1+exp(bias))      #For no correlated variable
     			temp <- runif(n,0,1)
  			m2[,i] <- gt > temp
   			temp <- runif(1, 0,1)
    			m2[,i] <- m2[,i]+(gt > temp)
		}
#### Topological data
	 n1 <- round(n/2)
 	 n2 <- round(n/4)
 	 n3 <- round(n/8)
 	 n4 <- n-n1-n2-n3 
 	 t1 = 2*pi*runif(n1, -1,1 )
 	 t2 = 2*pi*runif(n2, -1,1 ) 
  	 t3 = 2*pi*runif(n3, 0,1 ) 
 	 t4 = 2*pi*runif(n4, 0,1 )
 	 r1 <- 1
  	 r2 <- r1/2
  	 r3 <- r2/2
       r4 <- r3/2
	 X1 <- cbind(r1*cos(t1), r1*sin(t1))+0.01*rnorm(n1,0,1)
 	 X2 <- cbind(r2*cos(t2), r2*sin(t2))+0.01*rnorm(n2,0,1)
 	 X3 <- cbind(abs(r3*cos(t3)), r3*sin(t3))+ 0.01*rnorm(n3,0,1)
 	 X4 <- cbind(-abs(r4*cos(t4)), r4*sin(t4))+ 0.01*rnorm(n4,0,1)
	 m3 <- rbind(X1, X2, X3,X4) 
 ############## Catagorical data
        m4 <- GCP(n,2,c(4,3),5)
        m5 <- GSP(n,2,c(-5,3),2)
 	 #True h1, h2, and h3
       m4 <- as.matrix(scale(m4))
	 m5 <- as.matrix(scale(m5))  
      
     h1 <- rep(0, n)
	  for ( i in 1:10)
    		{
     		h1 <-  h1 +  sqrt(abs(sin(m1[,i])*cos(m1[,i])))
     		}

        h2 <- rep(0, n)
	  for ( i in 1:10)
    		{
     		h2 <-  h2 + m2[,i]*cos(m2[,i])
     		}
	  h3 <- rep(0, n)
  	  for ( i in 1:2)
    		{
     		h3 <-  h3 + m3[,i]*sin(m3[,i])
    		}

	 h4 <- rep(0, n)
  	 for ( i in 1:2)
    		{
     		h4 <-  h4 +i/sqrt(2)*exp(m4[,i])
    		}
       h5 <- rep(0, n)
  	 for ( i in 1:2)
    		{
     		h5 <-  h5 +sqrt(5)*log10(abs(m5[,i]))
    		}

	 h12 <- (1*2)*h1*h2
 	 h13 <- (1*3)*h1*h3
       h14 <- (1*3)*h1*h4
       h15 <- (1*3)*h1*h5
     	 h23 <- (2*3)*h2*h3
       h24 <- (2*4)*h2*h4
       h25 <- (2*5)*h2*h5
       h34 <- (3*4)*h3*h4
       h35 <- (3*5)*h3*h5
       h45 <- (4*5)*h4*h5

   	 h123 <- (1*2*3)*h1*h2*h3
       h124 <- (1*2*4)*h1*h2*h4
       h125 <- (1*2*5)*h1*h2*h5
       h234 <- (2*3*4)*h2*h3*h4
       h235 <- (2*3*5)*h2*h3*h5
       h345 <- (3*4*5)*h3*h4*h5

       h1234 <- (1*2*3*4)*h1*h2*h3*h4
       h1235 <- (1*2*3*5)*h1*h2*h3*h5
       h1245 <- (1*2*5*5)*h1*h2*h4*h5
       h1345 <- (1*3*4*5)*h1*h3*h4*h5
       h2345 <- (2*3*4*5)*h2*h3*h4*h5
       h12345 <- (1*2*3*4*5)*h1*h2*h3*h4*h5
 	 Y <-  X%*% beta + alpha1*(h1 + h2 + h3+h4+h5) + alpha2*(h12 + h13 +h14 + h15+ h23+h24+ h25+h34+h35+h45) + alpha3*(h123+ h124+h125+h234+h235+h345)+ alpha4*(h1234+ h1235+h1245+h1345+h2345)+ alpha5*h12345 + 0.001 * rnorm(n, 0, 1)
       Y <-as.vector(scale(Y))
       pr = 1/(1+exp(-Y))         # pass through an inv-logit function
       BY = rbinom(n,1,pr) 
       HOI <- GKHOIET(BY, X, m1, m2, m3, m4, m5, cutoff= 1)
       pLPCA <- parLinerPCA(BY,X, m1, m2, m3, m4, m5)
       fLPCA <-  fulLinerPCA(BY, X, m1, m2, m3, m4,m5)
       SKATa <- SKATLinerPCA (BY,X, m1, m2, m3, m4, m5)
     object <- list(OverallHOPV = HOI$Overall_test$p.value, HOIT= HOI$HOInterstion$p.value, ITpLPCA =pLPCA[1], ITfLPCA =fLPCA[1], skov =  SKATa[1], skit =   SKATa[2]) 
 return(object) 
 }

 
################################################# 
 #ptm <- proc.time() 
 #proc.time() - ptm
   G <-c()
       for(i in 1:2) # ng number of gen
         {     
            all <- Sim5DHOILKPCA(300,1,1,1,1,0.5)
             G <- rbind(G, c(all$OverallHOPV, all$HOIT,  all$ITpLPCA,  all$ITfLPCA,all$skov, all$skit))
  colnames(G) <- c("KMOV","KMHI","TpLHI","fLHI", "SKATOV", "SKATIT")
  cat("rep= ",i, "\n") 
}



  



